
/**
 *
 * @author marie
 * @param <E>
 */
public class Iterator<E> {
    boolean hasNext();
    
    E next();
    
    void remove() throws IllegalStateException;
}
