
/**
 *
 * @author marie
 * @param <E>
 */
public class Position<E> {
    /**
     * 
     * @return
     * @throws IllegalStateException 
     */
    E getElement() throws IllegalStateException;
}
