
/**
 *
 * @author Marie Larson
 * @version 2/12/2018
 */
public class Array2 extends Exception{
    public Array2(){
        
    }
    
    public Array2(String g){
        super(g);
    }
}
