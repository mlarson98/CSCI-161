
/**
 *
 * @author marie
 * @param <E>
 */
public class Iterable<E> {
    Iterator<E> iterator();
}
