
/**
 *
 * @author Marie Larson
 * @version 3.21.18
 */
public interface Position<E> {
    E getElement() throws IllegalStateException;
}
